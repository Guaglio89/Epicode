create database CarloGuagliardo_EsercitazioneFinale;

use CarloGuagliardo_EsercitazioneFinale;

CREATE TABLE PRODUCT(
ProductID SMALLINT PRIMARY KEY NOT NULL,
        ProductName VARCHAR(70),
        ProductCategoryName VARCHAR(80),
        UnitPrice DECIMAL(6,2)
);

CREATE TABLE REGION(
		RegionID SMALLINT PRIMARY KEY NOT NULL,
        RegionCode SMALLINT,
        RegionName VARCHAR(50),
        Country VARCHAR(30)
);

Alter table REGION rename column Country to Continent;

CREATE TABLE SALES (
    SalesOrderNumber VARCHAR(20) PRIMARY KEY NOT NULL,
    OrderQuantity SMALLINT,
    SalesDate DATE,
    UnitPrice DECIMAL(6,2),
    SalesAmount DECIMAL (8,2),
    ProductID SMALLINT,
    RegionID SMALLINT,
    FOREIGN KEY (ProductID) REFERENCES PRODUCT(ProductID),
    FOREIGN KEY (RegionID) REFERENCES REGION(RegionID)
);



INSERT INTO PRODUCT VALUES
        (1, 'Cottage House', 'Outdoor Games', 121.99),
        (2, 'Dinosaur Slide', 'Outdoor Games', 31.99),
        (3, 'Water Battle', 'Outdoor Games', 20.99),
		(4, 'Lego Disney', 'Construction Games', 53.99),
        (5, 'Sport Ball', 'Sports Games', 9.99),
		(6, 'Ravensburger Puzzle Pokemon 5000', 'Puzzle', 74.99),
        (7, 'Puzzle 2000 New York', 'Puzzle', 21.99),
        (8, 'Puzzle 4D Batman', 'Puzzle', 21.99),
        (9, 'Domino Double', 'Wooden Games', 10.99),
        (10, 'Police Transporter', 'Vehicles and Tracks', 27.99),
        (11, 'Dragon Monster Truck', 'Vehicles and Tracks', 17.99);
        
        INSERT INTO REGION VALUES
		(1, 'IT', 'Italy', 'Europe'),
		(2, 'ZA', 'South Africa', 'Africa'),
		(3, 'CN','China', 'Asia'),
		(4, 'BR', 'Brazil', 'South America'),
		(5, 'AU', 'Australia', 'Oceania');
        
       INSERT INTO SALES (SalesOrderNumber, SalesDate, OrderQuantity, UnitPrice, SalesAmount, ProductID, RegionID)
VALUES 
    (1, '2017-08-30', 2, 22.99, 45.98, 11, 1),
    (2, '2017-09-01', 1, 245.15, 245.15, 5, 2),
    (3, '2018-12-28', 2, 19.99, 39.98, 2, 3),
    (4, '2018-12-31', 2, 12.99, 25.98, 3, 4),
    (5, '2019-05-05', 2, 29.99, 49.98, 1, 5),
    (6, '2019-08-11', 1, 245.15, 245.15, 4, 1),
    (7, '2020-10-15', 1, 71.99, 71.99, 9, 2),
    (8, '2020-10-18', 2, 19.99, 39.98, 8, 3),
    (9, '2018-02-24', 8, 9.99, 79.92, 7, 4),
    (10, '2018-04-05', 4, 16.99, 67.96, 4, 5),
    (11, '2018-04-06', 2, 24.99, 49.98, 11, 1),
    (12, '2020-01-02', 4, 9.99, 39.96, 7, 2),
    (13, '2020-02-10', 2, 37.99, 75.98, 9, 3),
    (14, '2020-08-05', 1, 29.99, 29.99, 5, 4),
    (15, '2020-08-06', 2, 19.99, 39.98, 4, 5);
    
    -- 1. Verificare che i campi definiti come PK siano univoci. 
    
    select count(productid) -- 11 come risultato
    from product;
    
   select count(distinct productid) -- 11 come risultato
    from product; 

        SELECT -- 5 come risultato
    COUNT(regionid)
FROM
    region; 
    
     SELECT -- 5 come risultato
    COUNT(distinct regionid)
FROM
    region; 

 select count(salesordernumber) -- 15 come risultato
    from sales;
    
     select count(distinct salesordernumber) -- 15 come risultato
    from sales; 
    
   -- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 
   
   select p.ProductName, year(salesdate), sum(salesamount) as fatturato_tot
   from sales s
   inner join product p
   on s.productid = p.productid
   group by p.ProductName, p.ProductCategoryName, year(salesdate)
   order by year(salesdate);
   
   -- 3 Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
   
   select r.regionname, year(salesdate), sum(salesamount)
   from sales s
   inner join region r
   on s.regionid = r.regionid
   group by r.regionname, year(salesdate)
   order by r.regionname, year(salesdate) desc, sum(salesamount) desc;
   
   -- 4 Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 
   
	select p.productname, sum(orderquantity)
	from sales s
	inner join region r
	on s.regionid = r.regionid
	inner join product p
	on s.productid = p.productid
    group by p.productname
    order by sum(orderquantity) desc;

-- 5 Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.

   select p.productid, p.ProductName  -- risultato productid 6 e 10
   from product p
   left join sales s
   on s.productid = p.productid
   where s.productid is null;
   
   
   select productid, ProductName -- risultato productid 6 e 10
   from product
   where productid not in(select s.productid
				from sales s);
                
-- 6 Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).

   select p.productname, max(concat(year(salesdate),'-',month(salesdate))) as anno_mese
   from product p
   inner join sales s
   on s.productid = p.productid
   group by p.productname
   order by p.productname



